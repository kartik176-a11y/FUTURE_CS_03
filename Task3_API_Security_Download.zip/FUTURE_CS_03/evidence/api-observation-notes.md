# API Security Risk Analysis — Task 3

## 1. Objective and scope
This is a limited, passive review of requests observed while browsing the user's own local OWASP Juice Shop at `http://localhost:3000`. The supplied browser DevTools Network screenshot shows request entries including `/`, `set-current/`, `/e`, `application-configuration`, `Challenges/?name=Score...`, `Quantities/`, and a Socket.IO polling request. Some entries are marked XHR/fetch and several return HTTP 200; one third-party-looking request is shown as failed. This screenshot proves network activity was observed, but it does not by itself establish an API vulnerability.

## 2. Evidence reviewed
- `evidence/juice-shop-network-observations.png`: browser DevTools Network panel while Juice Shop was open.
- Related Task 1 evidence may also show headers for the same local training application, but it is not treated as proof of API-specific vulnerabilities here.

## 3. API risk review
| Risk area | What should be verified | Evidence status |
|---|---|---|
| Authentication | Are protected endpoints inaccessible without a valid session/token? | Not tested in supplied evidence. |
| Object/function authorization | Can a low-privilege user access another user's records or admin functions? | Not tested; requires authorized test accounts and explicit checks. |
| Excessive data exposure | Do responses contain fields beyond what the UI requires? | Network entries are visible, but response bodies were not provided; unconfirmed. |
| Input validation / injection | Are inputs validated and queries parameterized? | Not tested; no injection attempts were made. |
| CORS | Are cross-origin origins restricted appropriately for sensitive endpoints? | A homepage response showed `Access-Control-Allow-Origin: *`; endpoint-specific behavior and sensitivity need separate review. |
| Rate/resource limits | Are limits enforced for expensive or repeated requests? | Not tested. |
| Error handling | Do errors expose stack traces, secrets, or internal details? | No response body evidence sufficient to conclude this. |
| Transport security | Is HTTPS enforced for production deployment? | Local target used HTTP; this is expected for a local lab and does not establish production configuration. |
| Inventory/versioning | Are endpoints documented and deprecated endpoints retired? | Only a partial request list is visible; full inventory not established. |

## 4. Safe review checklist
1. Obtain written authorization and identify the test environment and owner.
2. Build an endpoint inventory with HTTP method, purpose, authentication, and data sensitivity.
3. Use only approved test accounts to verify object-level and function-level authorization.
4. Review response bodies for unnecessary sensitive fields, with all personal data redacted.
5. Review CORS per endpoint, authentication/session behavior, input validation, error handling, rate limits, and TLS configuration.
6. Record each finding with request/response evidence, expected versus observed behavior, impact, severity rationale, remediation, and retest result.
7. Avoid testing destructive operations or high-volume requests unless explicitly authorized.

## 5. Recommendations
- Enforce server-side authorization on every endpoint and object.
- Use explicit response schemas and allowlists for writable properties.
- Validate tokens and session state server-side; avoid secrets in URLs and logs.
- Restrict CORS to trusted origins when cross-origin access is required.
- Apply rate limits, timeouts, pagination caps, and request-size limits.
- Use parameterized queries and consistent safe error handling.
- Maintain an API inventory and monitor security-relevant events without logging secrets.

## 6. Conclusion and limitations
The provided screenshot demonstrates observed application/network requests to the local Juice Shop. It is evidence of traffic observation, not proof of a vulnerability. No active API tests, authorization bypass attempts, injection tests, or load tests were performed. This report is a preliminary risk analysis; a completed API-specific assessment requires further authorized evidence.
