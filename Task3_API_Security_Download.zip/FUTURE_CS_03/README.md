# FUTURE_CS_03 — API Security Risk Analysis

## Deliverables
- `report/API_Security_Risk_Analysis_Report.pdf`
- `evidence/juice-shop-network-observations.png` — browser DevTools Network screenshot
- `evidence/api-observation-notes.md` — observed traffic summary and API risk checklist

## Scope
The screenshot shows requests observed while browsing a local OWASP Juice Shop instance. It is not proof of a confirmed API vulnerability. No active API security tests were performed. Add further evidence if required by the official task brief.
